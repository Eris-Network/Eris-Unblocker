import { Proxy } from '../types';

export const proxies: Proxy[] = [
  {
    id: 'z-kit',
    name: 'Z-Kit',
    url: 'https://z-kit.net',
    description: 'Premium proxy service with high-speed connections and advanced security features.',
    featured: true,
    aboutblank: false
  },
  {
    id: 'interstellar',
    name: 'Interstellar',
    url: 'https://something-a-little-insanewhatthename.vercel.app/',
    description: 'A reliable, secure, and fast proxy. One of the most popular proxies ever created.',
    aboutblank: false
  },
  {
    id: 'mocha',
    name: 'Mocha',
    url: 'https://another-link-micah-made-wow.vercel.app/',
    description: 'A classy proxy, a little bit laggy sometimes, but contains a plethora of features.',
    aboutblank: true
  }
];