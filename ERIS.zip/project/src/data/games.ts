import { Game } from '../types';

export const games: Game[] = [
  {
    id: '1',
    name: 'Seraph',
    url: 'https://definitelynotblocked.vercel.app/',
    category: 'All',
    description: 'A comprehensive gaming platform with access to multiple games and entertainment options.',
    featured: true,
    aboutblank: true
  },
  {
    id: '2',
    name: 'ThePegLeg',
    url: 'https://sdfsdf.cbass92.org/asdjklhfskjafhakfhueoyraehfjkcnjkdscnsjakdreuoiwefh/embed.html',
    category: 'All',
    description: 'A gaming hub featuring various unblocked games and entertainment content.',
    aboutblank: true
  },
  {
    id: '3',
    name: 'Bidoofery',
    url: 'https://bidoofery.github.io/gfiles/list.html',
    category: 'All',
    description: 'A minimalist gaming website, but has many games.',
    aboutblank: true
  },
  {
    id: '4',
    name: 'Level Devil',
    url: 'https://leveldevil.io/home/',
    category: 'All',
    description: 'A simple, basic game website.',
    aboutblank: false
  },
  {
    id: '5',
    name: 'Virlan',
    url: 'https://www.virlan.co/unblocked-games/',
    category: 'All',
    description: 'A decently fancy website with a variety of games.',
    aboutblank: true
  },
  {
    id: '6',
    name: 'Maths Frame',
    url: 'https://mathsframe.github.io/',
    category: 'All',
    description: 'Slightly cluttered, but useful website with the basic list of games.',
    aboutblank: true
  },
  {
    id: '7',
    name: 'TBG95',
    url: 'https://tbg95.co/',
    category: 'All',
    description: 'A decent site, with a variety of games.',
    aboutblank: true
  },
  {
    id: '8',
    name: 'Unblocked Games Top',
    url: 'https://sites.google.com/site/unblockedgamestop/home',
    category: 'All',
    description: 'A typical unblocked games google site, but with an astounding amount of games.',
    aboutblank: false
  },
  {
    id: '9',
    name: 'Cool Math Games',
    url: 'https://coolmathgames.com',
    category: 'All',
    description: 'A classic, complete with a wide variety of unblocked games.',
    aboutblank: false
  },
  {
    id: '10',
    name: 'Boxel Rebound',
    url: 'https://trinculo54.github.io/Boxel-rebound-hope/Older/',
    category: 'All',
    description: 'A skill based jumping game.',
    aboutblank: true
  },
];