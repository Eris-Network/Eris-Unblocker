import React, { useState } from 'react';
import { useEffect } from 'react';
import { Gamepad2, Shield, Settings, Terminal, Info, ExternalLink, X } from 'lucide-react';
import { TabType } from './types';
import { TabButton } from './components/TabButton';
import { GameCard } from './components/GameCard';
import { ProxyCard } from './components/ProxyCard';
import { ThemeSelector } from './components/ThemeSelector';
import { AboutPage } from './components/AboutPage';
import { DisguisePage } from './components/DisguisePage';
import { useTheme } from './contexts/ThemeContext';
import { games } from './data/games';
import { proxies } from './data/proxies';

function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('games');
  const [showDisguise, setShowDisguise] = useState(true);
  const [showSecretModal, setShowSecretModal] = useState(false);
  const { theme } = useTheme();

  // Listen for messages from parent window (when in iframe)
  useEffect(() => {
    // Check URL parameters for skip disguise and tab selection
    const urlParams = new URLSearchParams(window.location.search);
    const skipDisguise = urlParams.get('skip-disguise');
    const tab = urlParams.get('tab');
    
    if (skipDisguise === 'true') {
      setShowDisguise(false);
      if (tab === 'games') {
        setCurrentTab('games');
      }
    }
  }, []);

  // If disguise is active, show the boring website
  if (showDisguise) {
    return <DisguisePage onAccess={() => setShowDisguise(false)} />;
  }

  const renderContent = () => {
    switch (currentTab) {
      case 'games':
        return (
          <div className="space-y-8 animate-fade-in">
            <div className="text-center space-y-3">
              <h2 className={`text-4xl font-bold animate-slide-up ${
                theme === 'dark' ? 'text-white' : theme === 'light' ? 'text-gray-900' : 'text-gray-200'
              }`}>Game Collection</h2>
              <p className={`text-lg animate-slide-up animation-delay-100 ${
                theme === 'dark' ? 'text-gray-400' : theme === 'light' ? 'text-gray-700' : 'text-gray-400'
              }`}>Access your favorite games instantly</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {games.map((game, index) => (
                <div key={game.id} className="animate-slide-up" style={{ animationDelay: `${index * 100}ms` }}>
                  <GameCard game={game} />
                </div>
              ))}
            </div>

            {/* Secret Button - Only visible on games tab */}
            <div className="flex justify-center pt-8">
              <button
                onClick={() => setShowSecretModal(true)}
                className={`px-2 py-1 text-xs font-mono transition-all duration-300 select-none ${getSecretButtonClasses()}`}
                style={{ 
                  userSelect: 'none',
                  WebkitUserSelect: 'none',
                  MozUserSelect: 'none',
                  msUserSelect: 'none'
                }}
              >
                secret
              </button>
            </div>
          </div>
        );
        
      case 'proxies':
        return (
          <div className="space-y-8 animate-fade-in">
            <div className="text-center space-y-3">
              <h2 className={`text-4xl font-bold animate-slide-up ${
                theme === 'dark' ? 'text-white' : theme === 'light' ? 'text-gray-900' : 'text-gray-200'
              }`}>Proxy Services</h2>
              <p className={`text-lg animate-slide-up animation-delay-100 ${
                theme === 'dark' ? 'text-gray-400' : theme === 'light' ? 'text-gray-700' : 'text-gray-400'
              }`}>Secure and anonymous browsing solutions</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {proxies.map((proxy, index) => (
                <div key={proxy.id} className="animate-slide-up" style={{ animationDelay: `${index * 150}ms` }}>
                  <ProxyCard proxy={proxy} />
                </div>
              ))}
            </div>
          </div>
        );
        
      case 'about':
        return <AboutPage />;
        
      case 'other':
        return <ThemeSelector />;
        
      default:
        return null;
    }
  };

  const getBackgroundClasses = () => {
    if (theme === 'light') {
      return 'bg-gradient-to-br from-orange-50 via-yellow-50 to-red-50';
    }
    if (theme === 'chill') {
      return 'bg-gradient-to-br from-gray-900 via-gray-800 to-black';
    }
    return 'bg-gradient-to-br from-slate-900 via-gray-900 to-blue-950';
  };

  const getBackgroundElements = () => {
    if (theme === 'light') {
      return (
        <>
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-400/15 rounded-full blur-3xl animate-pulse-slow" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-orange-400/15 rounded-full blur-3xl animate-pulse-slow animation-delay-1000" />
          <div className="absolute top-3/4 left-1/2 w-64 h-64 bg-yellow-400/15 rounded-full blur-3xl animate-pulse-slow animation-delay-2000" />
        </>
      );
    }
    if (theme === 'chill') {
      return (
        <>
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gray-600/8 rounded-full blur-3xl animate-pulse-slow" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gray-500/8 rounded-full blur-3xl animate-pulse-slow animation-delay-1000" />
          <div className="absolute top-3/4 left-1/2 w-64 h-64 bg-gray-700/8 rounded-full blur-3xl animate-pulse-slow animation-delay-2000" />
        </>
      );
    }
    return (
      <>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/6 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/6 rounded-full blur-3xl animate-pulse-slow animation-delay-1000" />
        <div className="absolute top-3/4 left-1/2 w-64 h-64 bg-purple-500/6 rounded-full blur-3xl animate-pulse-slow animation-delay-2000" />
      </>
    );
  };

  const getPatternOpacity = () => theme === 'light' ? 'opacity-20' : 'opacity-50';

  const getSecretButtonClasses = () => {
    if (theme === 'light') {
      return 'text-orange-200/40 hover:text-orange-300/60';
    }
    if (theme === 'chill') {
      return 'text-gray-700/40 hover:text-gray-600/60';
    }
    return 'text-slate-700/40 hover:text-slate-600/60';
  };

  const getModalClasses = () => {
    if (theme === 'light') {
      return 'bg-white/95 border-orange-200';
    }
    if (theme === 'chill') {
      return 'bg-gray-800/95 border-gray-600';
    }
    return 'bg-gray-900/95 border-gray-700';
  };

  const getModalTextClasses = () => {
    if (theme === 'light') {
      return 'text-gray-900';
    }
    if (theme === 'chill') {
      return 'text-gray-200';
    }
    return 'text-white';
  };

  const getModalDescriptionClasses = () => {
    if (theme === 'light') {
      return 'text-gray-700';
    }
    if (theme === 'chill') {
      return 'text-gray-400';
    }
    return 'text-gray-400';
  };

  const getModalButtonClasses = () => {
    if (theme === 'light') {
      return 'bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white';
    }
    if (theme === 'chill') {
      return 'bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-gray-200';
    }
    return 'bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white';
  };

  const getCloseButtonClasses = () => {
    if (theme === 'light') {
      return 'text-gray-500 hover:text-gray-700 hover:bg-gray-100';
    }
    if (theme === 'chill') {
      return 'text-gray-400 hover:text-gray-200 hover:bg-gray-700';
    }
    return 'text-gray-400 hover:text-gray-200 hover:bg-gray-800';
  };

  return (
    <div className={`min-h-screen ${getBackgroundClasses()} relative overflow-hidden transition-all duration-300`}>
      {/* Animated background elements */}
      <div className="absolute inset-0">
        {getBackgroundElements()}
      </div>
      
      {/* Background pattern */}
      <div className={`absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%23${theme === 'light' ? '000000' : 'ffffff'}%22 fill-opacity=%22${theme === 'light' ? '0.03' : '0.02'}%22%3E%3Ccircle cx=%2230%22 cy=%2230%22 r=%221%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] ${getPatternOpacity()}`} />
      
      {/* Secret Modal */}
      {showSecretModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setShowSecretModal(false)}
          />
          
          {/* Modal */}
          <div className={`relative backdrop-blur-sm border rounded-2xl p-8 max-w-md w-full animate-slide-up ${getModalClasses()}`}>
            {/* Close button */}
            <button
              onClick={() => setShowSecretModal(false)}
              className={`absolute top-4 right-4 p-2 rounded-lg transition-colors duration-200 ${getCloseButtonClasses()}`}
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-6">
              {/* Header */}
              <div className="text-center space-y-2">
                <h2 className={`text-2xl font-bold ${getModalTextClasses()}`}>
                  SecretV2
                </h2>
                <p className={`text-sm ${getModalDescriptionClasses()}`}>
                  A worse and previous prototype of eris
                </p>
              </div>

              {/* Button */}
              <div className="flex justify-center">
                <a
                  href="https://sites.google.com/philasd.org/secretv2/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`inline-flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all duration-300 transform hover:scale-105 ${getModalButtonClasses()}`}
                >
                  <span>Visit SecretV2</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className="relative z-10">
        {/* Header */}
        <header className={`border-b backdrop-blur-sm animate-slide-down transition-all duration-300 ${
          theme === 'dark' ? 'border-gray-800/50' : theme === 'light' ? 'border-orange-200/50' : 'border-gray-700/50'
        }`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 animate-slide-right">
                <div className={`p-3 rounded-xl animate-glow ${
                  theme === 'dark' 
                    ? 'bg-gradient-to-br from-slate-700/30 to-blue-800/30' 
                    : theme === 'light'
                    ? 'bg-gradient-to-br from-red-400/20 to-orange-400/20'
                    : 'bg-gradient-to-br from-gray-600/20 to-gray-700/20'
                }`}>
                  <Terminal className={`w-10 h-10 ${
                    theme === 'dark' ? 'text-blue-400' : theme === 'light' ? 'text-red-500' : 'text-gray-400'
                  }`} />
                </div>
                <div>
                  <h1 className={`text-4xl font-bold bg-clip-text text-transparent animate-gradient ${
                    theme === 'dark' 
                      ? 'bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-400' 
                      : theme === 'light'
                      ? 'bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500'
                      : 'bg-gradient-to-r from-gray-400 via-gray-500 to-gray-600'
                  }`}>
                    Eris
                  </h1>
                  <p className={`text-sm animate-fade-in animation-delay-500 ${
                    theme === 'dark' ? 'text-gray-400' : theme === 'light' ? 'text-gray-700' : 'text-gray-400'
                  }`}>Anonymous • Secure • Fast</p>
                </div>
              </div>
              
              <div className={`hidden sm:flex items-center space-x-1 backdrop-blur-sm rounded-xl p-1 border animate-slide-left transition-all duration-300 ${
                theme === 'dark' ? 'bg-gray-900/50 border-gray-800' : theme === 'light' ? 'bg-white/70 border-orange-200' : 'bg-gray-800/50 border-gray-700'
              }`}>
                <TabButton
                  tab="games"
                  currentTab={currentTab}
                  onClick={setCurrentTab}
                  label="Games"
                  icon={<Gamepad2 className="w-5 h-5" />}
                />
                <TabButton
                  tab="proxies"
                  currentTab={currentTab}
                  onClick={setCurrentTab}
                  label="Proxies"
                  icon={<Shield className="w-5 h-5" />}
                />
                <TabButton
                  tab="about"
                  currentTab={currentTab}
                  onClick={setCurrentTab}
                  label="About"
                  icon={<Info className="w-5 h-5" />}
                />
                <TabButton
                  tab="other"
                  currentTab={currentTab}
                  onClick={setCurrentTab}
                  label="Other"
                  icon={<Settings className="w-5 h-5" />}
                />
              </div>
            </div>
            
            {/* Mobile navigation */}
            <div className={`sm:hidden mt-6 flex space-x-1 backdrop-blur-sm rounded-xl p-1 border animate-slide-up animation-delay-300 transition-all duration-300 ${
              theme === 'dark' ? 'bg-gray-900/50 border-gray-800' : theme === 'light' ? 'bg-white/70 border-orange-200' : 'bg-gray-800/50 border-gray-700'
            }`}>
              <TabButton
                tab="games"
                currentTab={currentTab}
                onClick={setCurrentTab}
                label="Games"
                icon={<Gamepad2 className="w-5 h-5" />}
              />
              <TabButton
                tab="proxies"
                currentTab={currentTab}
                onClick={setCurrentTab}
                label="Proxies"
                icon={<Shield className="w-5 h-5" />}
              />
              <TabButton
                tab="about"
                currentTab={currentTab}
                onClick={setCurrentTab}
                label="About"
                icon={<Info className="w-5 h-5" />}
              />
              <TabButton
                tab="other"
                currentTab={currentTab}
                onClick={setCurrentTab}
                label="Other"
                icon={<Settings className="w-5 h-5" />}
              />
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {renderContent()}
        </main>

        {/* Footer */}
        <footer className={`border-t mt-20 animate-fade-in animation-delay-1000 transition-all duration-300 ${
          theme === 'dark' ? 'border-gray-800/50' : theme === 'light' ? 'border-orange-200/50' : 'border-gray-700/50'
        }`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0">
              <p className={theme === 'dark' ? 'text-gray-500' : theme === 'light' ? 'text-gray-700' : 'text-gray-500'}>
                © 2025 Eris. Anonymous browsing made simple.
              </p>
              <div className="flex items-center space-x-4">
                <span className={`text-xs ${theme === 'dark' ? 'text-gray-600' : theme === 'light' ? 'text-gray-600' : 'text-gray-600'}`}>Secure</span>
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                <span className={`text-xs ${theme === 'dark' ? 'text-gray-600' : theme === 'light' ? 'text-gray-600' : 'text-gray-600'}`}>Online</span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;