export const openInBlankTab = (url: string): void => {
  try {
    const win = window.open('about:blank', '_blank');
    
    if (win) {
      win.document.body.style.margin = '0';
      win.document.body.style.height = '100vh';
      win.document.body.style.padding = '0';
      win.document.body.style.overflow = 'hidden';
      
      const iframe = win.document.createElement('iframe');
      iframe.style.border = 'none';
      iframe.style.width = '100%';
      iframe.style.height = '100%';
      iframe.style.margin = '0';
      iframe.style.padding = '0';
      iframe.src = url;
      
      win.document.body.appendChild(iframe);
    }
  } catch (error) {
    window.open(url, '_blank');
  }
};

export const openNormally = (url: string): void => {
  window.open(url, '_blank');
};