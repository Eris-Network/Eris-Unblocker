export interface Game {
  id: string;
  name: string;
  url: string;
  category?: string;
  description: string;
  featured?: boolean;
  aboutblank?: boolean;
}

export interface Proxy {
  id: string;
  name: string;
  url: string;
  description: string;
  featured?: boolean;
  aboutblank?: boolean;
}

export type TabType = 'games' | 'proxies' | 'about' | 'other';