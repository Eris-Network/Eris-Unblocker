import React from 'react';
import { Shield, Star } from 'lucide-react';
import { Proxy } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { openInBlankTab, openNormally } from '../utils/linkHandler';

interface ProxyCardProps {
  proxy: Proxy;
}

export const ProxyCard: React.FC<ProxyCardProps> = ({ proxy }) => {
  const { theme } = useTheme();
  
  const handleClick = () => {
    if (proxy.aboutblank) {
      openInBlankTab(proxy.url);
    } else {
      openNormally(proxy.url);
    }
  };

  const getCardClasses = () => {
    const baseClasses = 'group relative backdrop-blur-sm border rounded-3xl p-10 cursor-pointer transition-all duration-300 transform-gpu';
    
    if (proxy.featured) {
      if (theme === 'light') {
        return `${baseClasses} bg-gradient-to-br from-red-100/80 to-orange-100/80 border-red-300/60 hover:border-red-400 hover:shadow-xl hover:shadow-red-400/25 col-span-full lg:col-span-2 hover:scale-105`;
      }
      if (theme === 'chill') {
        return `${baseClasses} bg-gradient-to-br from-gray-800/40 to-gray-900/40 border-gray-500/30 hover:border-gray-400/50 hover:shadow-xl hover:shadow-gray-400/15 col-span-full lg:col-span-2 hover:scale-105`;
      }
      return `${baseClasses} bg-gradient-to-br from-slate-800/40 to-blue-900/40 border-blue-400/30 hover:border-blue-400/50 hover:shadow-xl hover:shadow-blue-400/15 col-span-full lg:col-span-2 hover:scale-105`;
    }
    
    if (theme === 'light') {
      return `${baseClasses} bg-white/80 border-yellow-200 hover:border-yellow-400/60 hover:shadow-xl hover:shadow-yellow-400/20 hover:scale-105`;
    }
    
    if (theme === 'chill') {
      return `${baseClasses} bg-gray-800/60 border-gray-600/50 hover:border-gray-400/40 hover:shadow-xl hover:shadow-gray-400/10 hover:scale-105`;
    }
    
    return `${baseClasses} bg-gray-900/60 border-gray-700/50 hover:border-indigo-400/40 hover:shadow-xl hover:shadow-indigo-400/10 hover:scale-105`;
  };

  const getGlowClasses = () => {
    if (proxy.featured) {
      if (theme === 'light') {
        return 'bg-gradient-to-r from-red-400/15 to-orange-400/15';
      }
      if (theme === 'chill') {
        return 'bg-gradient-to-r from-gray-400/8 to-gray-500/8';
      }
      return 'bg-gradient-to-r from-blue-400/8 to-indigo-400/8';
    }
    
    if (theme === 'light') {
      return 'bg-gradient-to-r from-yellow-400/12 to-orange-400/12';
    }
    
    if (theme === 'chill') {
      return 'bg-gradient-to-r from-gray-400/6 to-gray-500/6';
    }
    
    return 'bg-gradient-to-r from-indigo-400/6 to-purple-400/6';
  };

  const getIconBgClasses = () => {
    if (proxy.featured) {
      if (theme === 'light') {
        return 'bg-gradient-to-br from-red-400/25 to-orange-400/25';
      }
      if (theme === 'chill') {
        return 'bg-gradient-to-br from-gray-400/20 to-gray-500/20';
      }
      return 'bg-gradient-to-br from-blue-400/20 to-indigo-400/20';
    }
    
    if (theme === 'light') {
      return 'bg-gradient-to-br from-yellow-400/25 to-orange-400/25';
    }
    
    if (theme === 'chill') {
      return 'bg-gradient-to-br from-gray-400/15 to-gray-500/15';
    }
    
    return 'bg-gradient-to-br from-indigo-400/15 to-purple-400/15';
  };

  const getIconColorClasses = () => {
    if (proxy.featured) {
      if (theme === 'light') {
        return 'text-red-600 group-hover:text-red-500';
      }
      if (theme === 'chill') {
        return 'text-gray-300 group-hover:text-gray-200';
      }
      return 'text-blue-400 group-hover:text-blue-300';
    }
    
    if (theme === 'light') {
      return 'text-yellow-600 group-hover:text-yellow-500';
    }
    
    if (theme === 'chill') {
      return 'text-gray-400 group-hover:text-gray-300';
    }
    
    return 'text-indigo-400 group-hover:text-indigo-300';
  };

  const getTitleColorClasses = () => {
    if (proxy.featured) {
      if (theme === 'light') {
        return 'text-red-700 group-hover:text-red-600';
      }
      if (theme === 'chill') {
        return 'text-gray-200 group-hover:text-gray-100';
      }
      return 'text-blue-300 group-hover:text-blue-200';
    }
    
    if (theme === 'light') {
      return 'text-gray-900 group-hover:text-yellow-700';
    }
    
    if (theme === 'chill') {
      return 'text-gray-200 group-hover:text-gray-100';
    }
    
    return 'text-white group-hover:text-indigo-300';
  };

  const getDescriptionColorClasses = () => {
    if (theme === 'light') {
      return 'text-gray-700 group-hover:text-gray-800';
    }
    
    if (theme === 'chill') {
      return 'text-gray-300 group-hover:text-gray-200';
    }
    
    return 'text-gray-300 group-hover:text-gray-200';
  };

  const getAboutBlankBgClasses = () => {
    if (theme === 'light') {
      return 'bg-orange-100/80';
    }
    
    if (theme === 'chill') {
      return 'bg-gray-700/60';
    }
    
    return 'bg-slate-800/60';
  };

  const getAboutBlankTextClasses = () => {
    if (theme === 'light') {
      return 'text-orange-700';
    }
    
    if (theme === 'chill') {
      return 'text-gray-300';
    }
    
    return 'text-gray-400';
  };

  const getButtonClasses = () => {
    if (proxy.featured) {
      if (theme === 'light') {
        return 'bg-red-400/25 text-red-700 group-hover:bg-red-400/35 group-hover:text-red-800';
      }
      if (theme === 'chill') {
        return 'bg-gray-400/15 text-gray-300 group-hover:bg-gray-400/25 group-hover:text-gray-200';
      }
      return 'bg-blue-400/15 text-blue-300 group-hover:bg-blue-400/25 group-hover:text-blue-200';
    }
    
    if (theme === 'light') {
      return 'bg-yellow-400/25 text-yellow-800 group-hover:bg-yellow-400/35 group-hover:text-yellow-900';
    }
    
    if (theme === 'chill') {
      return 'bg-gray-400/15 text-gray-300 group-hover:bg-gray-400/25 group-hover:text-gray-200';
    }
    
    return 'bg-indigo-400/15 text-indigo-300 group-hover:bg-indigo-400/25 group-hover:text-indigo-200';
  };

  const getFeaturedBadgeClasses = () => {
    if (theme === 'light') {
      return 'bg-red-400/25 group-hover:bg-red-400/35';
    }
    if (theme === 'chill') {
      return 'bg-gray-400/15 group-hover:bg-gray-400/25';
    }
    return 'bg-blue-400/15 group-hover:bg-blue-400/25';
  };

  return (
    <div onClick={handleClick} className={getCardClasses()}>
      {/* Subtle glow effect */}
      <div className={`absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 ${getGlowClasses()}`} />
      
      <div className="relative z-10 flex flex-col space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className={`p-4 rounded-xl transition-all duration-300 group-hover:scale-110 ${getIconBgClasses()}`}>
              <Shield className={`w-8 h-8 transition-colors duration-300 ${getIconColorClasses()}`} />
            </div>
            
            <div className="flex flex-col space-y-2">
              <h3 className={`text-2xl font-bold transition-colors duration-300 ${getTitleColorClasses()}`}>
                {proxy.name}
              </h3>
              
              {proxy.aboutblank && (
                <div className={`px-2 py-1 rounded text-xs font-mono w-fit transition-colors duration-300 ${getAboutBlankBgClasses()} ${getAboutBlankTextClasses()}`}>
                  about:blank
                </div>
              )}
            </div>
          </div>
          
          {proxy.featured && (
            <div className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-colors duration-300 ${getFeaturedBadgeClasses()}`}>
              <Star className="w-5 h-5 text-yellow-500 fill-current" />
              <span className={`text-sm font-medium ${
                theme === 'light' ? 'text-red-700' : theme === 'chill' ? 'text-gray-300' : 'text-blue-300'
              }`}>Featured</span>
            </div>
          )}
        </div>
        
        <p className={`leading-relaxed text-lg transition-colors duration-300 ${getDescriptionColorClasses()}`}>
          {proxy.description}
        </p>
        
        <div className="pt-4">
          <span className={`inline-flex items-center px-6 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${getButtonClasses()}`}>
            Access Proxy →
          </span>
        </div>
      </div>
    </div>
  );
};