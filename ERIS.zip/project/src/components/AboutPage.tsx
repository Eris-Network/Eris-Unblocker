import React from 'react';
import { Info, Shield, Users, FileText, Heart, ExternalLink, AlertTriangle } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

export const AboutPage: React.FC = () => {
  const { theme } = useTheme();

  const getCardClasses = () => {
    const baseClasses = 'backdrop-blur-sm border rounded-2xl p-8 transition-all duration-300';
    
    if (theme === 'light') {
      return `${baseClasses} bg-white/80 border-orange-200 hover:border-orange-400/60 hover:shadow-xl hover:shadow-orange-400/15`;
    }
    
    if (theme === 'chill') {
      return `${baseClasses} bg-gray-800/60 border-gray-600/50 hover:border-gray-400/40 hover:shadow-xl hover:shadow-gray-400/10`;
    }
    
    return `${baseClasses} bg-gray-900/60 border-gray-700/50 hover:border-indigo-400/40 hover:shadow-xl hover:shadow-indigo-400/10`;
  };

  const getIconBgClasses = () => {
    if (theme === 'light') {
      return 'bg-gradient-to-br from-orange-400/25 to-yellow-400/25';
    }
    
    if (theme === 'chill') {
      return 'bg-gradient-to-br from-gray-400/15 to-gray-500/15';
    }
    
    return 'bg-gradient-to-br from-indigo-400/15 to-purple-400/15';
  };

  const getIconColorClasses = () => {
    if (theme === 'light') {
      return 'text-orange-600';
    }
    
    if (theme === 'chill') {
      return 'text-gray-400';
    }
    
    return 'text-indigo-400';
  };

  const getTitleColorClasses = () => {
    if (theme === 'light') {
      return 'text-gray-900';
    }
    
    if (theme === 'chill') {
      return 'text-gray-200';
    }
    
    return 'text-white';
  };

  const getTextColorClasses = () => {
    if (theme === 'light') {
      return 'text-gray-700';
    }
    
    if (theme === 'chill') {
      return 'text-gray-400';
    }
    
    return 'text-gray-400';
  };

  const getLinkColorClasses = () => {
    if (theme === 'light') {
      return 'text-orange-600 hover:text-orange-700';
    }
    
    if (theme === 'chill') {
      return 'text-gray-300 hover:text-gray-200';
    }
    
    return 'text-indigo-400 hover:text-indigo-300';
  };

  const getWarningCardClasses = () => {
    if (theme === 'light') {
      return 'bg-red-50/80 border-red-300/60';
    }
    
    if (theme === 'chill') {
      return 'bg-gray-800/40 border-gray-500/30';
    }
    
    return 'bg-red-900/20 border-red-400/30';
  };

  const getWarningTextClasses = () => {
    if (theme === 'light') {
      return 'text-red-800';
    }
    
    if (theme === 'chill') {
      return 'text-gray-300';
    }
    
    return 'text-red-300';
  };

  const sections = [
    {
      icon: <Info className="w-6 h-6" />,
      title: 'About Eris',
      content: (
        <div className="space-y-4">
          <p>
            Eris is a comprehensive platform providing access to games and secure proxy services. 
            Our mission is to offer anonymous, secure, and fast browsing solutions while maintaining 
            user privacy and accessibility.
          </p>
          <p>
            Built with modern web technologies, Eris features a responsive design that adapts to 
            your preferences with multiple theme options and an intuitive user interface.
          </p>
        </div>
      )
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: 'Credits & Acknowledgments',
      content: (
        <div className="space-y-4">
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Developer</h4>
            <div className="space-y-2">
              <p><strong>Micah Brubaker</strong></p>
              <div className="space-y-1">
                <p>Contact me at:</p>
                <ul className="space-y-1 ml-4">
                  <li>
                    • <a 
                        href="https://github.com/Eris-Network" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className={`inline-flex items-center space-x-1 ${getLinkColorClasses()}`}
                      >
                        <span>https://github.com/Eris-Network</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                  </li>
                  <li>• eris.network.unblocker@gmail.com (RARELY CHECKED)</li>
                </ul>
              </div>
            </div>
          </div>
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Third-Party Services</h4>
            <ul className="space-y-1">
              <li>• Game platforms and proxy services listed on our platform</li>
              <li>• Lucide React for beautiful icons</li>
              <li>• Tailwind CSS for responsive styling</li>
              <li>• React and TypeScript for robust development</li>
            </ul>
          </div>
        </div>
      )
    },
    {
      icon: <FileText className="w-6 h-6" />,
      title: 'Terms of Use',
      content: (
        <div className="space-y-4">
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Acceptable Use</h4>
            <ul className="space-y-1">
              <li>• Use Eris responsibly and in accordance with applicable laws</li>
              <li>• Respect the terms of service of linked external platforms</li>
              <li>• Do not use our services for illegal activities</li>
              <li>• Be respectful to other users and service providers</li>
            </ul>
          </div>
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Service Availability</h4>
            <p>
              While we strive to maintain high availability, Eris is provided "as is" without 
              warranties. External links and services are maintained by third parties and may 
              experience downtime or changes beyond our control.
            </p>
          </div>
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Content Disclaimer</h4>
            <p>
              Eris serves as a directory and access point to external services. We do not host 
              games or proxy content directly and are not responsible for the content, availability, 
              or policies of linked external sites.
            </p>
          </div>
        </div>
      )
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: 'Privacy & Security',
      content: (
        <div className="space-y-4">
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Data Collection</h4>
            <p>
              Eris respects your privacy. We do not collect personal information, track browsing 
              habits, or store user data. Your theme preferences are saved locally in your browser.
            </p>
          </div>
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Security Measures</h4>
            <ul className="space-y-1">
              <li>• All external links open in secure contexts</li>
              <li>• About:blank functionality for enhanced privacy</li>
              <li>• No tracking scripts or analytics</li>
              <li>• Secure HTTPS connections where available</li>
            </ul>
          </div>
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Proxy Services</h4>
            <p>
              When using proxy services through Eris, remember that your traffic passes through 
              third-party servers. Choose reputable proxy providers and be aware of their privacy policies.
            </p>
          </div>
        </div>
      )
    },
    {
      icon: <Heart className="w-6 h-6" />,
      title: 'Support & Community',
      content: (
        <div className="space-y-4">
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Getting Help</h4>
            <p>
              If you encounter issues with Eris or have suggestions for improvement, we encourage 
              community feedback and support through appropriate channels.
            </p>
          </div>
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Contributing</h4>
            <p>
              Eris thrives on community contributions. Whether it's reporting bugs, suggesting 
              features, or helping other users, every contribution makes Eris better for everyone.
            </p>
          </div>
          <div>
            <h4 className={`font-semibold mb-2 ${getTitleColorClasses()}`}>Feedback</h4>
            <p>
              Your feedback helps us improve Eris continuously. We value user input and strive 
              to implement features that enhance the overall experience.
            </p>
          </div>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="text-center space-y-3">
        <div className="flex items-center justify-center space-x-3 animate-slide-up">
          <div className={`p-3 rounded-xl animate-glow ${
            theme === 'dark' 
              ? 'bg-gradient-to-br from-slate-700/30 to-blue-800/30' 
              : theme === 'light'
              ? 'bg-gradient-to-br from-red-400/20 to-orange-400/20'
              : 'bg-gradient-to-br from-gray-600/20 to-gray-700/20'
          }`}>
            <Info className={`w-8 h-8 ${
              theme === 'dark' ? 'text-blue-400' : theme === 'light' ? 'text-red-500' : 'text-gray-400'
            }`} />
          </div>
          <h2 className={`text-4xl font-bold ${getTitleColorClasses()}`}>
            About Eris
          </h2>
        </div>
        <p className={`text-lg animate-slide-up animation-delay-100 ${getTextColorClasses()}`}>
          Learn more about our platform, policies, and community
        </p>
      </div>

      {/* Important Notice */}
      <div className={`backdrop-blur-sm border rounded-2xl p-6 animate-slide-up animation-delay-200 ${getWarningCardClasses()}`}>
        <div className="flex items-start space-x-4">
          <div className="flex-shrink-0">
            <AlertTriangle className={`w-6 h-6 ${
              theme === 'light' ? 'text-red-600' : theme === 'chill' ? 'text-gray-300' : 'text-red-400'
            }`} />
          </div>
          <div>
            <h3 className={`text-lg font-semibold mb-2 ${
              theme === 'light' ? 'text-red-800' : theme === 'chill' ? 'text-gray-200' : 'text-red-300'
            }`}>
              Important Notice
            </h3>
            <p className={`text-sm leading-relaxed ${getWarningTextClasses()}`}>
              Eris provides access to external gaming and proxy services. Users are responsible for 
              complying with their institution's policies, local laws, and the terms of service of 
              external platforms. Use responsibly and at your own discretion.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {sections.map((section, index) => (
          <div
            key={section.title}
            className={`animate-slide-up ${getCardClasses()}`}
            style={{ animationDelay: `${(index + 3) * 150}ms` }}
          >
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <div className={`p-3 rounded-xl ${getIconBgClasses()}`}>
                  <div className={`transition-colors duration-300 ${getIconColorClasses()}`}>
                    {section.icon}
                  </div>
                </div>
                <h3 className={`text-2xl font-bold ${getTitleColorClasses()}`}>
                  {section.title}
                </h3>
              </div>
              
              <div className={`leading-relaxed ${getTextColorClasses()}`}>
                {section.content}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Footer Links */}
      <div className="text-center space-y-4 animate-fade-in animation-delay-1000">
        <div className="flex flex-wrap justify-center gap-6">
          <a
            href="#"
            className={`inline-flex items-center space-x-2 text-sm font-medium transition-colors duration-300 ${getLinkColorClasses()}`}
          >
            <FileText className="w-4 h-4" />
            <span>Full Terms</span>
            <ExternalLink className="w-3 h-3" />
          </a>
          <a
            href="#"
            className={`inline-flex items-center space-x-2 text-sm font-medium transition-colors duration-300 ${getLinkColorClasses()}`}
          >
            <Shield className="w-4 h-4" />
            <span>Privacy Policy</span>
            <ExternalLink className="w-3 h-3" />
          </a>
          <a
            href="#"
            className={`inline-flex items-center space-x-2 text-sm font-medium transition-colors duration-300 ${getLinkColorClasses()}`}
          >
            <Users className="w-4 h-4" />
            <span>Community Guidelines</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
        
        <p className={`text-xs ${
          theme === 'light' ? 'text-gray-600' : 'text-gray-500'
        }`}>
          Last updated: {new Date().toLocaleDateString()}
        </p>
      </div>
    </div>
  );
};