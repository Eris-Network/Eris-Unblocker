import React, { useState } from 'react';
import { Book, User, Calendar, Search, Menu, X, Lock, Unlock } from 'lucide-react';

interface DisguisePageProps {
  onAccess: () => void;
}

export const DisguisePage: React.FC<DisguisePageProps> = ({ onAccess }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSection, setSelectedSection] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [transitionPhase, setTransitionPhase] = useState<'fade' | 'lock' | 'unlock'>('fade');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.toLowerCase().trim() === 'open the gates') {
      // Start transition animation first
      setIsTransitioning(true);
      setTransitionPhase('fade');
      
      setTimeout(() => {
        setTransitionPhase('lock');
      }, 1000);
      
      setTimeout(() => {
        setTransitionPhase('unlock');
      }, 2500);
      
      setTimeout(() => {
        // Open Eris in about:blank tab after transition
        try {
          const win = window.open('about:blank', '_blank');
          
          if (win) {
            win.document.body.style.margin = '0';
            win.document.body.style.height = '100vh';
            win.document.body.style.padding = '0';
            win.document.body.style.overflow = 'hidden';
            win.document.body.style.backgroundColor = '#0f172a';
            
            const iframe = win.document.createElement('iframe');
            iframe.style.border = 'none';
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.style.margin = '0';
            iframe.style.padding = '0';
            iframe.src = `${window.location.origin}?skip-disguise=true&tab=games`;
            
            win.document.body.appendChild(iframe);
          }
        } catch (error) {
          // Fallback to normal transition if about:blank fails
          onAccess();
        }
      }, 3500);
    } else {
      // Search through biographies
      const searchResults = biographies.filter(bio => 
        bio.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bio.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bio.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
      
      if (searchResults.length > 0) {
        const resultNames = searchResults.map(bio => bio.name).join(', ');
        alert(`Found ${searchResults.length} biography(ies): ${resultNames}`);
      } else {
        alert('No biographies found matching your search.');
      }
      setSearchTerm('');
    }
  };

  const handleSectionClick = (section: string) => {
    if (section !== 'home') {
      if (section === 'authors') {
        const authorList = biographies.map(bio => bio.name).join(', ');
        alert(`Our featured authors include: ${authorList}`);
      } else if (section === 'timeline') {
        alert('Timeline view coming soon! Currently featuring biographies from Ancient Greece to Modern Day.');
      } else if (section === 'search') {
        alert('Advanced search coming soon! Use the main search bar to find biographies.');
      }
    }
    setSelectedSection(section);
    setMobileMenuOpen(false);
  };

  // Sample biographies data
  const biographies = [
    {
      name: "Albert Einstein",
      category: "Scientists",
      description: "Theoretical physicist who developed the theory of relativity and won the Nobel Prize in Physics.",
      period: "1879-1955",
      achievements: "Theory of Relativity, Nobel Prize in Physics"
    },
    {
      name: "Marie Curie",
      category: "Scientists", 
      description: "First woman to win a Nobel Prize and the only person to win Nobel Prizes in two different sciences.",
      period: "1867-1934",
      achievements: "Nobel Prizes in Physics and Chemistry"
    },
    {
      name: "Leonardo da Vinci",
      category: "Artists",
      description: "Renaissance polymath known for his paintings, inventions, and scientific observations.",
      period: "1452-1519", 
      achievements: "Mona Lisa, The Last Supper, Flying Machine designs"
    },
    {
      name: "Nelson Mandela",
      category: "Leaders",
      description: "Anti-apartheid revolutionary who became South Africa's first Black president.",
      period: "1918-2013",
      achievements: "Nobel Peace Prize, End of Apartheid, First Black President of South Africa"
    },
    {
      name: "William Shakespeare",
      category: "Writers",
      description: "English playwright and poet widely regarded as the greatest writer in the English language.",
      period: "1564-1616",
      achievements: "Romeo and Juliet, Hamlet, Macbeth, 39 plays and 154 sonnets"
    },
    {
      name: "Cleopatra VII",
      category: "Leaders",
      description: "Last active pharaoh of Ptolemaic Egypt, known for her intelligence and political acumen.",
      period: "69-30 BCE",
      achievements: "Ruled Egypt for nearly two decades, spoke multiple languages"
    }
  ];

  const sections = [
    { id: 'home', name: 'Home', icon: <Book className="w-4 h-4" /> },
    { id: 'authors', name: 'Authors', icon: <User className="w-4 h-4" /> },
    { id: 'timeline', name: 'Timeline', icon: <Calendar className="w-4 h-4" /> },
    { id: 'search', name: 'Advanced Search', icon: <Search className="w-4 h-4" /> }
  ];

  if (isTransitioning) {
    return (
      <div className="fixed inset-0 z-50 overflow-hidden">
        {/* Fading page backdrop */}
        <div 
          className={`absolute inset-0 transition-all duration-1000 ease-out ${
            transitionPhase === 'fade' 
              ? 'opacity-100 scale-100' 
              : 'opacity-0 scale-150 blur-sm'
          }`}
        >
          <div className="min-h-screen bg-gray-50 opacity-30" />
        </div>
        
        {/* Dark background */}
        <div 
          className={`absolute inset-0 bg-gradient-to-br from-slate-900 via-gray-900 to-blue-950 transition-opacity duration-1000 ${
            transitionPhase === 'fade' ? 'opacity-0' : 'opacity-100'
          }`}
        />
        
        {/* Lock animation - Properly centered container */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div 
            className={`flex flex-col items-center justify-center transition-all duration-1000 ease-out ${
              transitionPhase === 'fade' 
                ? 'opacity-0 scale-50' 
                : transitionPhase === 'lock'
                ? 'opacity-100 scale-100'
                : 'opacity-100 scale-110'
            }`}
          >
            {transitionPhase === 'unlock' ? (
              <>
                {/* Unlocked state with glow */}
                <div className="relative mb-6">
                  <div className="absolute inset-0 animate-pulse">
                    <div className="w-24 h-24 bg-blue-400/20 rounded-full blur-xl" />
                  </div>
                  <Unlock className="w-24 h-24 text-blue-400 relative z-10 animate-bounce" />
                </div>
                <div className="text-blue-300 text-lg font-light animate-fade-in">
                  Access Granted
                </div>
              </>
            ) : (
              <>
                {/* Locked state */}
                <div className="mb-6">
                  <Lock className={`w-24 h-24 text-gray-400 transition-all duration-500 ${
                    transitionPhase === 'lock' ? 'animate-pulse' : ''
                  }`} />
                </div>
                <div className="text-gray-400 text-lg font-light">
                  Authenticating...
                </div>
              </>
            )}
          </div>
        </div>
        
        {/* Subtle background pattern */}
        <div className={`absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%23ffffff%22 fill-opacity=%220.02%22%3E%3Ccircle cx=%2230%22 cy=%2230%22 r=%221%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-50 transition-opacity duration-1000 ${
          transitionPhase === 'fade' ? 'opacity-0' : 'opacity-100'
        }`} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <Book className="w-8 h-8 text-gray-600" />
              <h1 className="text-2xl font-serif text-gray-800">Simply Biographies</h1>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => handleSectionClick(section.id)}
                  className={`flex items-center space-x-2 px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                    selectedSection === section.id
                      ? 'text-blue-600 border-b-2 border-blue-600'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {section.icon}
                  <span>{section.name}</span>
                </button>
              ))}
            </nav>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-gray-600 hover:text-gray-900"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-gray-200 py-4">
              <nav className="flex flex-col space-y-2">
                {sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => handleSectionClick(section.id)}
                    className={`flex items-center space-x-2 px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                      selectedSection === section.id
                        ? 'text-blue-600 bg-blue-50'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    {section.icon}
                    <span>{section.name}</span>
                  </button>
                ))}
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif text-gray-800 mb-4">
            Discover Life Stories
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore comprehensive biographies of notable figures throughout history. 
            Search our extensive database to learn about the lives that shaped our world.
          </p>
        </div>

        {/* Search Section */}
        <div className="max-w-2xl mx-auto mb-16">
          <form onSubmit={handleSearch} className="relative">
            <div className="flex">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search for biographies..."
                className="flex-1 px-4 py-3 border border-gray-300 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700 transition-colors duration-200 flex items-center space-x-2"
              >
                <Search className="w-5 h-5" />
                <span>Search</span>
              </button>
            </div>
          </form>
        </div>

        {/* Featured Content */}
        <div className="mb-16">
          <h3 className="text-2xl font-semibold text-gray-800 mb-8 text-center">Featured Biographies</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {biographies.map((bio, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-200 cursor-pointer"
                   onClick={() => alert(`${bio.name} (${bio.period})\n\n${bio.description}\n\nKey Achievements: ${bio.achievements}`)}>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-medium text-blue-600 bg-blue-100 px-2 py-1 rounded">{bio.category}</span>
                  <span className="text-xs text-gray-500">{bio.period}</span>
                </div>
                <h4 className="text-lg font-semibold text-gray-800 mb-2">{bio.name}</h4>
                <p className="text-gray-600 text-sm leading-relaxed">{bio.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Categories */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {['Scientists', 'Artists', 'Leaders', 'Writers'].map((category, index) => {
            const categoryBios = biographies.filter(bio => bio.category === category);
            const icons = { Scientists: '🔬', Artists: '🎨', Leaders: '👑', Writers: '✍️' };
            return (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow duration-200 text-center">
                <div className="text-4xl mb-4">{icons[category as keyof typeof icons]}</div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">{category}</h3>
                <p className="text-gray-600 text-sm mb-2">{categoryBios.length} biographies</p>
                <p className="text-gray-500 text-xs">{categoryBios.map(bio => bio.name).join(', ')}</p>
              </div>
            );
          })}
        </div>

        {/* Browse by Era */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-16">
          <h3 className="text-2xl font-semibold text-gray-800 mb-6 text-center">Browse by Historical Era</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 border rounded-lg hover:bg-gray-50 transition-colors duration-200">
              <h4 className="font-semibold text-gray-800 mb-2">Ancient Times</h4>
              <p className="text-sm text-gray-600">Cleopatra VII and other ancient leaders</p>
            </div>
            <div className="text-center p-4 border rounded-lg hover:bg-gray-50 transition-colors duration-200">
              <h4 className="font-semibold text-gray-800 mb-2">Renaissance</h4>
              <p className="text-sm text-gray-600">Leonardo da Vinci, Shakespeare, and Renaissance masters</p>
            </div>
            <div className="text-center p-4 border rounded-lg hover:bg-gray-50 transition-colors duration-200">
              <h4 className="font-semibold text-gray-800 mb-2">Modern Era</h4>
              <p className="text-sm text-gray-600">Einstein, Curie, Mandela, and modern pioneers</p>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <h3 className="text-2xl font-semibold text-gray-800 mb-6">Our Collection</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            <div>
              <div className="text-3xl font-bold text-blue-600 mb-2">{biographies.length}</div>
              <div className="text-gray-600">Biographies</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-600 mb-2">{new Set(biographies.map(bio => bio.category)).size}</div>
              <div className="text-gray-600">Categories</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-600 mb-2">4</div>
              <div className="text-gray-600">Time Periods</div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <Book className="w-6 h-6" />
              <span className="text-xl font-serif">Simply Biographies</span>
            </div>
            <p className="text-gray-400 text-sm">
              © 2025 Simply Biographies. Educational content for research purposes.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};