import React from 'react';
import { Gamepad2, Star } from 'lucide-react';
import { Game } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { openInBlankTab, openNormally } from '../utils/linkHandler';

interface GameCardProps {
  game: Game;
}

export const GameCard: React.FC<GameCardProps> = ({ game }) => {
  const { theme } = useTheme();
  
  const handleClick = () => {
    if (game.aboutblank) {
      openInBlankTab(game.url);
    } else {
      openNormally(game.url);
    }
  };

  const getCardClasses = () => {
    const baseClasses = 'group relative backdrop-blur-sm border rounded-2xl p-6 cursor-pointer transition-all duration-300 transform-gpu';
    
    if (game.featured) {
      if (theme === 'light') {
        return `${baseClasses} bg-gradient-to-br from-red-100/80 to-orange-100/80 border-red-300/60 hover:border-red-400 hover:shadow-xl hover:shadow-red-400/25 hover:scale-105`;
      }
      if (theme === 'chill') {
        return `${baseClasses} bg-gradient-to-br from-gray-800/40 to-gray-900/40 border-gray-500/30 hover:border-gray-400/50 hover:shadow-xl hover:shadow-gray-400/15 hover:scale-105`;
      }
      return `${baseClasses} bg-gradient-to-br from-slate-800/40 to-blue-900/40 border-blue-400/30 hover:border-blue-400/50 hover:shadow-xl hover:shadow-blue-400/15 hover:scale-105`;
    }
    
    if (theme === 'light') {
      return `${baseClasses} bg-white/80 border-orange-200 hover:border-orange-400/60 hover:shadow-xl hover:shadow-orange-400/15 hover:scale-105`;
    }
    
    if (theme === 'chill') {
      return `${baseClasses} bg-gray-800/60 border-gray-600/50 hover:border-gray-400/40 hover:shadow-xl hover:shadow-gray-400/10 hover:scale-105`;
    }
    
    return `${baseClasses} bg-gray-900/60 border-gray-700/50 hover:border-indigo-400/40 hover:shadow-xl hover:shadow-indigo-400/10 hover:scale-105`;
  };

  const getGlowClasses = () => {
    if (game.featured) {
      if (theme === 'light') {
        return 'bg-gradient-to-r from-red-400/15 to-orange-400/15';
      }
      if (theme === 'chill') {
        return 'bg-gradient-to-r from-gray-400/8 to-gray-500/8';
      }
      return 'bg-gradient-to-r from-blue-400/8 to-indigo-400/8';
    }
    
    if (theme === 'light') {
      return 'bg-gradient-to-r from-orange-400/12 to-yellow-400/12';
    }
    
    if (theme === 'chill') {
      return 'bg-gradient-to-r from-gray-400/6 to-gray-500/6';
    }
    
    return 'bg-gradient-to-r from-indigo-400/6 to-purple-400/6';
  };

  const getIconBgClasses = () => {
    if (game.featured) {
      if (theme === 'light') {
        return 'bg-gradient-to-br from-red-400/25 to-orange-400/25';
      }
      if (theme === 'chill') {
        return 'bg-gradient-to-br from-gray-400/20 to-gray-500/20';
      }
      return 'bg-gradient-to-br from-blue-400/20 to-indigo-400/20';
    }
    
    if (theme === 'light') {
      return 'bg-gradient-to-br from-orange-400/25 to-yellow-400/25';
    }
    
    if (theme === 'chill') {
      return 'bg-gradient-to-br from-gray-400/15 to-gray-500/15';
    }
    
    return 'bg-gradient-to-br from-indigo-400/15 to-purple-400/15';
  };

  const getIconColorClasses = () => {
    if (game.featured) {
      if (theme === 'light') {
        return 'text-red-600 group-hover:text-red-500';
      }
      if (theme === 'chill') {
        return 'text-gray-300 group-hover:text-gray-200';
      }
      return 'text-blue-400 group-hover:text-blue-300';
    }
    
    if (theme === 'light') {
      return 'text-orange-600 group-hover:text-orange-500';
    }
    
    if (theme === 'chill') {
      return 'text-gray-400 group-hover:text-gray-300';
    }
    
    return 'text-indigo-400 group-hover:text-indigo-300';
  };

  const getTitleColorClasses = () => {
    if (game.featured) {
      if (theme === 'light') {
        return 'text-red-700 group-hover:text-red-600';
      }
      if (theme === 'chill') {
        return 'text-gray-200 group-hover:text-gray-100';
      }
      return 'text-blue-300 group-hover:text-blue-200';
    }
    
    if (theme === 'light') {
      return 'text-gray-900 group-hover:text-orange-700';
    }
    
    if (theme === 'chill') {
      return 'text-gray-200 group-hover:text-gray-100';
    }
    
    return 'text-white group-hover:text-indigo-300';
  };

  const getCategoryColorClasses = () => {
    if (theme === 'light') {
      return 'text-gray-600 group-hover:text-gray-700';
    }
    
    if (theme === 'chill') {
      return 'text-gray-500 group-hover:text-gray-400';
    }
    
    return 'text-gray-500 group-hover:text-gray-400';
  };

  const getDescriptionColorClasses = () => {
    if (theme === 'light') {
      return 'text-gray-700 group-hover:text-gray-800';
    }
    
    if (theme === 'chill') {
      return 'text-gray-400 group-hover:text-gray-300';
    }
    
    return 'text-gray-400 group-hover:text-gray-300';
  };

  const getAboutBlankBgClasses = () => {
    if (theme === 'light') {
      return 'bg-orange-100/80';
    }
    
    if (theme === 'chill') {
      return 'bg-gray-700/60';
    }
    
    return 'bg-slate-800/60';
  };

  const getAboutBlankTextClasses = () => {
    if (theme === 'light') {
      return 'text-orange-700';
    }
    
    if (theme === 'chill') {
      return 'text-gray-300';
    }
    
    return 'text-gray-400';
  };

  const getFeaturedBadgeClasses = () => {
    if (theme === 'light') {
      return 'bg-red-400/25 group-hover:bg-red-400/35';
    }
    if (theme === 'chill') {
      return 'bg-gray-400/15 group-hover:bg-gray-400/25';
    }
    return 'bg-blue-400/15 group-hover:bg-blue-400/25';
  };

  return (
    <div onClick={handleClick} className={getCardClasses()}>
      {/* Subtle glow effect */}
      <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 ${getGlowClasses()}`} />
      
      <div className="relative z-10 flex flex-col space-y-4">
        {/* Header with icon, about:blank indicator, and featured badge */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`p-3 rounded-xl transition-all duration-300 group-hover:scale-110 ${getIconBgClasses()}`}>
              <Gamepad2 className={`w-8 h-8 transition-colors duration-300 ${getIconColorClasses()}`} />
            </div>
            
            {game.aboutblank && (
              <div className={`px-2 py-1 rounded text-xs font-mono transition-colors duration-300 ${getAboutBlankBgClasses()} ${getAboutBlankTextClasses()}`}>
                about:blank
              </div>
            )}
          </div>
          
          {game.featured && (
            <div className={`flex items-center space-x-1 px-3 py-1 rounded-full transition-colors duration-300 ${getFeaturedBadgeClasses()}`}>
              <Star className="w-4 h-4 text-yellow-500 fill-current" />
              <span className={`text-xs font-medium ${
                theme === 'light' ? 'text-red-700' : theme === 'chill' ? 'text-gray-300' : 'text-blue-300'
              }`}>Featured</span>
            </div>
          )}
        </div>
        
        {/* Content */}
        <div className="space-y-3">
          <div className="space-y-1">
            <h3 className={`text-xl font-bold transition-colors duration-300 ${getTitleColorClasses()}`}>
              {game.name}
            </h3>
            {game.category && (
              <p className={`text-xs transition-colors duration-300 uppercase tracking-wide font-medium ${getCategoryColorClasses()}`}>
                {game.category}
              </p>
            )}
          </div>
          
          <p className={`text-sm transition-colors duration-300 leading-relaxed ${getDescriptionColorClasses()}`}>
            {game.description}
          </p>
        </div>
      </div>
    </div>
  );
};