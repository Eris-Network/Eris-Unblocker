import React from 'react';
import { TabType } from '../types';
import { useTheme } from '../contexts/ThemeContext';

interface TabButtonProps {
  tab: TabType;
  currentTab: TabType;
  onClick: (tab: TabType) => void;
  label: string;
  icon: React.ReactNode;
}

export const TabButton: React.FC<TabButtonProps> = ({ tab, currentTab, onClick, label, icon }) => {
  const isActive = currentTab === tab;
  const { theme } = useTheme();
  
  const getButtonClasses = () => {
    if (isActive) {
      if (theme === 'light') {
        return 'bg-gradient-to-r from-red-500/20 to-orange-500/20 text-red-600 border border-red-400/40 scale-105 shadow-lg shadow-red-400/25';
      }
      if (theme === 'chill') {
        return 'bg-gradient-to-r from-gray-500/15 to-gray-600/15 text-gray-300 border border-gray-400/25 scale-105 shadow-lg shadow-gray-400/15';
      }
      return 'bg-gradient-to-r from-blue-500/15 to-indigo-500/15 text-blue-400 border border-blue-400/25 scale-105 shadow-lg shadow-blue-400/15';
    }
    
    if (theme === 'light') {
      return 'text-gray-700 hover:text-red-600 hover:bg-red-50/80 hover:scale-105';
    }
    if (theme === 'chill') {
      return 'text-gray-500 hover:text-gray-300 hover:bg-gray-700/50 hover:scale-105';
    }
    
    return 'text-gray-400 hover:text-blue-300 hover:bg-slate-800/50 hover:scale-105';
  };
  
  const getActiveGradient = () => {
    if (theme === 'light') {
      return 'bg-gradient-to-r from-red-400/15 to-orange-500/15';
    }
    if (theme === 'chill') {
      return 'bg-gradient-to-r from-gray-400/8 to-gray-500/8';
    }
    return 'bg-gradient-to-r from-blue-400/8 to-indigo-500/8';
  };
  
  return (
    <button
      onClick={() => onClick(tab)}
      className={`relative flex items-center space-x-3 px-8 py-4 rounded-xl font-medium transition-all duration-300 transform-gpu ${getButtonClasses()}`}
    >
      <div className={`transition-colors duration-300 ${
        isActive 
          ? (theme === 'light' ? 'text-red-600' : theme === 'chill' ? 'text-gray-300' : 'text-blue-400')
          : ''
      }`}>
        {icon}
      </div>
      <span className="font-semibold">{label}</span>
      
      {isActive && (
        <div className={`absolute inset-0 rounded-xl border border-transparent -z-10 ${getActiveGradient()}`} />
      )}
    </button>
  );
};